package model;

import java.awt.*;

public class shapeColorToColor {
    public static Color getColor(String color){
        Color rtnColor = null;
        switch (color){
            case"BLUE":
                rtnColor = Color.BLUE;
                break;
            case"CYAN":
                rtnColor = Color.CYAN;
                break;
            case"DARK_GRAY":
                rtnColor = Color.DARK_GRAY;
                break;
            case"GRAY":
                rtnColor = Color.GRAY;
                break;
            case"GREEN":
                rtnColor = Color.GREEN;
                break;
            case"LIGHT_GRAY":
                rtnColor = Color.LIGHT_GRAY;
                break;
            case"MAGENTA":
                rtnColor = Color.MAGENTA;
                break;
            case"ORANGE":
                rtnColor = Color.ORANGE;
                break;
            case"PINK":
                rtnColor = Color.PINK;
                break;
            case"RED":
                rtnColor = Color.RED;
                break;
            case"WHITE":
                rtnColor = Color.WHITE;
                break;
            case"YELLOW":
                rtnColor = Color.YELLOW;
                break;
            default:
                rtnColor = Color.BLACK;
                break;
        }

        return rtnColor;
    }
}
