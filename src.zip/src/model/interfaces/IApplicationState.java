package model.interfaces;

import controller.shapes.Shapes;
import model.ShapeColor;
import model.ShapeShadingType;
import model.ShapeType;
import model.StartAndEndPointMode;

import java.util.ArrayList;

public interface IApplicationState {
    void setActiveShape();

    void setActivePrimaryColor();

    void setActiveSecondaryColor();

    void setActiveShadingType();

    void setActiveStartAndEndPointMode();

    void addShapeToShapeList(Shapes shape);
    void removeShape(Shapes index);
    //selected
    void updateShapeList(ArrayList<Shapes> shapeList);
    void setCopiedShapeList(ArrayList<Shapes> copiedList);
    //groups
    void addShapeArray(Shapes[] groups);
    void removeShapeArray(Shapes[] groups);



    ShapeType getActiveShapeType();

    ShapeColor getActivePrimaryColor();

    ShapeColor getActiveSecondaryColor();

    ShapeShadingType getActiveShapeShadingType();

    StartAndEndPointMode getActiveStartAndEndPointMode();

    ArrayList<Shapes> getShapeList();
    ArrayList<Shapes> getCopiedShapeList();
    ArrayList<Shapes[]> getGroupLists();




}
