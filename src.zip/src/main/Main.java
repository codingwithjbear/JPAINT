package main;

import controller.*;
import model.ShapeColor;
import model.ShapeType;
import model.persistence.ApplicationState;
import view.EventName;
import view.gui.Gui;
import view.gui.GuiWindow;
import view.gui.PaintCanvas;
import view.interfaces.IGuiWindow;
import view.interfaces.PaintCanvasBase;
import view.interfaces.IUiModule;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Main {
    public static void main (String[] args) {
        PaintCanvasBase paintCanvas = new PaintCanvas();
        IGuiWindow guiWindow = new GuiWindow(paintCanvas);
        IUiModule uiModule = new Gui(guiWindow);
        ApplicationState appState = new ApplicationState(uiModule);
        IJPaintController controller = new JPaintController(uiModule, appState);
        controller.setup();
        paintCanvas.addMouseListener(new MyMouseHandler(paintCanvas, appState));




    }
}
