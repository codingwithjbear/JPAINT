package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.*;
import model.ShapeType;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;
import java.util.ArrayList;

import static controller.shapes.ShapeMods.redraw;
import static controller.shapes.ShapeMods.selectGroup;

public class SelectCommand  implements ICommand {
    private IApplicationState appState;
    private PaintCanvasBase paintCanvas;
    private ArrayList<Shapes> shapeList;

    @Override
    public void run() {
        this.appState = MyMouseHandler.getAppState();
        this.paintCanvas = MyMouseHandler.getPaintCanvas();
        this.shapeList = appState.getShapeList();
        selectShape();
    }

    private void selectShape(){
        ShapesFactory factory = new ShapesFactory();
        Shapes invisible = factory.makeShape();
        for(Shapes shape : shapeList){
            if(isIntersect(shape,invisible)){
                    if(shape.getGroupNumber() > -1) {
                        selectGroup(shape.getGroupNumber(), appState, paintCanvas);
                        break;
                    }
                    else {
                        shape.setSelected(true);
                        switch (shape.getShapeType()) {
                            case RECTANGLE:
                                rectangle rectangle = new rectangle();
                                rectangle.selectShape(shape, paintCanvas);
                                break;
                            case ELLIPSE:
                                ellipse ellipse = new ellipse();
                                ellipse.selectShape(shape, paintCanvas);
                                break;
                            case TRIANGLE:
                                triangle triangle = new triangle();
                                triangle.selectShape(shape, paintCanvas);
                                break;
                        }
                    }
                }
            if(!isIntersect(shape, invisible) && shape.isSelected()){
                shape.setSelected(false);
                //redraw();
                redraw(shapeList,paintCanvas);
            }

            }
        appState.updateShapeList(shapeList);
        }

    private boolean isIntersect(Shapes shape, Shapes invisible){
        if(shape.getShapeType().equals(ShapeType.TRIANGLE)){
            Polygon x = new Polygon(shape.getxArr(),shape.getyArr(),3);
            return x.intersects(invisible.getX(),invisible.getY(),Math.max(invisible.getWidth(), 1),Math.max(invisible.getHeight(), 1));
        }

        Rectangle rect = new Rectangle(shape.getX(),shape.getY(),shape.getWidth(), shape.getHeight());
        return rect.intersects(invisible.getX(),invisible.getY(),Math.max(invisible.getWidth(), 1),Math.max(invisible.getHeight(), 1));

    }

}
