package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.*;
import model.ShapeType;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.util.ArrayList;

import static controller.shapes.ShapeMods.redraw;

public class MoveCommand  implements IUndoRedo {
    private IApplicationState appState;
    private PaintCanvasBase paintCanvas;
    private ArrayList<Shapes> shapeList;
    private int dx,dy;
    private boolean redo = false;

    @Override
    public void run() {
        CommandHistory.add(this);
        this.appState = MyMouseHandler.getAppState();
        this.paintCanvas = MyMouseHandler.getPaintCanvas();
        this.shapeList = appState.getShapeList();
        ShapesFactory factory = new ShapesFactory();
        Shapes selected = factory.makeShape();
        dx = selected.getEndPoint().x - selected.getStartPoint().x;
        dy = selected.getEndPoint().y - selected.getStartPoint().y;
        moveShape();
    }

    @Override
    public void redo(){
            redo = true;
            run();
            redo = false;
        }

    @Override
    public void undo () {
            shapeList = appState.getShapeList();
            for (Shapes shape : shapeList) {
                if (shape.isSelected()) {
                    int dx = shape.getDx();
                    int dy = shape.getDy();

                    if (shape.getShapeType().equals(ShapeType.TRIANGLE)) {
                        int[] xArr = shape.getxArr();
                        int[] yArr = shape.getyArr();

                        for (int i = 0; i < 3; i++) {
                            xArr[i] -= dx;
                            yArr[i] -= dy;
                        }
                        shape.setxArr(xArr);
                        shape.setyArr(yArr);
                    } else {
                        shape.setX(shape.getX() - dx);
                        shape.setY(shape.getY() - dy);
                        shape.setWidth(shape.getWidth());
                        shape.setHeight(shape.getHeight());
                    }
                    appState.updateShapeList(shapeList);
                    redraw(shapeList, paintCanvas);
                }
            }
        }

    private void moveShape() {
        shapeList = appState.getShapeList();
        for (Shapes shape : shapeList) {
            if (shape.isSelected()) {
                if(redo) {
                    dx = shape.getDx();
                    dy = shape.getDy();
                }

                if(shape.getShapeType().equals(ShapeType.TRIANGLE)){
                    int[] xArr = shape.getxArr();
                    int[] yArr = shape.getyArr();

                    for(int i = 0; i < 3; i++){xArr[i] += dx; yArr[i] += dy;}
                    shape.setxArr(xArr);
                    shape.setyArr(yArr);
                }
                else {
                    shape.setX(dx + shape.getX());
                    shape.setY(dy + shape.getY());
                    shape.setWidth(shape.getWidth());
                    shape.setHeight(shape.getHeight());
                }
                shape.setDx(dx);
                shape.setDy(dy);

                appState.updateShapeList(shapeList);
                redraw(shapeList,paintCanvas);
            }
        }

    }

    }
