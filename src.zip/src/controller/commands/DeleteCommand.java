package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.Shapes;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.util.ArrayList;

import static controller.shapes.ShapeMods.redraw;

public class DeleteCommand implements IUndoRedo {
    private ArrayList<Shapes> deleted;
    private ArrayList<Shapes> shapesList;
    private PaintCanvasBase paintCanvas;

    @Override
    public void run() {
        CommandHistory.add(this);
        IApplicationState appState = MyMouseHandler.getAppState();
        this.paintCanvas = MyMouseHandler.getPaintCanvas();
        this.shapesList = appState.getShapeList();
        ArrayList<Shapes> delete = new ArrayList<>();

        for(Shapes shape : shapesList){
            if(shape.isSelected()){
                delete.add(shape);
            }
        }
        this.deleted = delete;
        shapesList.removeAll(delete);
        redraw(shapesList, paintCanvas);
    }

    @Override
    public void redo(){run();}

    @Override
    public void undo(){
        shapesList.addAll(deleted);
        redraw(shapesList, paintCanvas);
    }
}
