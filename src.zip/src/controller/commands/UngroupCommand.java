package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.Shapes;
import model.interfaces.IApplicationState;

import java.util.ArrayList;

public class UngroupCommand implements IUndoRedo {
    private ArrayList<Shapes> shapesList;
    private IApplicationState appState;
    private ArrayList<Shapes> group;
    private int savedGroupNumber;
    @Override
    public void run() {
        CommandHistory.add(this);
        appState = MyMouseHandler.getAppState();
        shapesList = appState.getShapeList();
        group = new ArrayList<>();
        int groupNumber = -1;

        for(Shapes shape : shapesList){
            if(shape.isSelected()){
                savedGroupNumber = shape.getGroupNumber();
                group.add(shape);
                shape.setGroupNumber(groupNumber);
            }
        }
    }

    public void redo() {
        for (Shapes shape : shapesList) {
            for (int index = 0; index < group.size(); index++) {
                if (group.get(index) == null) break;
                int tmp = shape.getGroupNumber();
                shape.setGroupNumber(savedGroupNumber);
                if (shape.equals(group.get(index))) {
                    shape.setGroupNumber(-1);
                } else {
                    shape.setGroupNumber(tmp);
                }
            }
        }
    }


    public void undo() {
        for(Shapes shape : shapesList){
            for (int index = 0; index < group.size(); index++) {
                int tmp = shape.getGroupNumber();
                shape.setGroupNumber(savedGroupNumber);
                if (shape.equals(group.get(index))) {
                    shape.setGroupNumber(savedGroupNumber);
                } else {
                    shape.setGroupNumber(tmp);
                }
            }
        }

    }
}
