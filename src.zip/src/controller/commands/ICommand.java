package controller.commands;

/*
Command Pattern (ICommand, DrawCommand, SelectCommand, MoveCommand) implemented and used in MyMouseHandler
Command Pattern (ICommand, CopyCommand, PasteCommand, DeleteCommand, GroupCommand, UngroupCommand) implemented and used in JPaintController
 */
public interface ICommand {
    void run();
}
