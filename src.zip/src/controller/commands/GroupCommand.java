package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.Shapes;
import model.interfaces.IApplicationState;

import java.util.ArrayList;

public class GroupCommand implements IUndoRedo {

    private ArrayList<Shapes> shapesList;
    private ArrayList<Shapes[]> groups;
    private IApplicationState appState;
    private Shapes[] group;
    private int savedGroupNumber;

    @Override
    public void run() {
        CommandHistory.add(this);
        appState = MyMouseHandler.getAppState();
        shapesList = appState.getShapeList();
        group = new Shapes[shapesList.size()];
        groups = appState.getGroupLists();
        int index = 0;
        int groupNumber = savedGroupNumber = groups.size();

        for(Shapes shape : shapesList){
            if(shape.isSelected()){
                shape.setGroupNumber(groupNumber);
                group[index] = shape;
            }
            index++;
        }
        appState.addShapeArray(group);

    }

    public void redo() {
        for(Shapes shape : shapesList){
            for(int index = 0; index < group.length; index++) {
                int tmp = shape.getGroupNumber();
                shape.setGroupNumber(savedGroupNumber);
                if (shape.equals(group[index])) {
                    shape.setGroupNumber(savedGroupNumber);
                }
                else {
                    shape.setGroupNumber(tmp);
                }
            }
        }
    }

    public void undo() {
        for(Shapes shape : shapesList){
            for(int index = 0; index < group.length; index++) {
                if (shape.equals(group[index])) {
                    shape.setGroupNumber(-1);
                }
            }
        }

    }
}
