package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.*;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.util.ArrayList;

import static controller.shapes.ShapeMods.copyShape;
import static controller.shapes.ShapeMods.redraw;

public class PasteCommand implements IUndoRedo {
    private ArrayList<Shapes> copiedShapesList;
    private ArrayList<Shapes> shapesList;
    private PaintCanvasBase paintCanvas;
    private IApplicationState appState;

    @Override
    public void run() {
        CommandHistory.add(this);
        appState = MyMouseHandler.getAppState();
        paintCanvas = MyMouseHandler.getPaintCanvas();
        shapesList = appState.getShapeList();
        copiedShapesList = appState.getCopiedShapeList();


        for (Shapes shapes : copiedShapesList) appState.addShapeToShapeList(shapes);

        redraw(shapesList, paintCanvas);

    }

    @Override
    public void redo() {
        run();
    }

    @Override
    public void undo() {
        shapesList.removeAll(copiedShapesList);
        appState.updateShapeList(shapesList);
        redraw(shapesList, paintCanvas);

    }

}
