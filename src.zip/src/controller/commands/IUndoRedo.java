package controller.commands;

/*
Adapter Pattern (ICommand, IUndoRedo, CommandHistory, DrawCommand, MoveCommand, CopyCommand, PasteCommand, DeleteCommand, GroupCommand, UngroupCommand) implemented and used in JPaintController
 */

public interface IUndoRedo extends ICommand {
    void redo();
    void undo();
}
