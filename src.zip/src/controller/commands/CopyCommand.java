package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.Shapes;
import model.interfaces.IApplicationState;

import java.util.ArrayList;

import static controller.shapes.ShapeMods.copyShape;

public class CopyCommand implements ICommand {

    @Override
    public void run() {
        IApplicationState appState = MyMouseHandler.getAppState();
        ArrayList<Shapes> shapesList = appState.getShapeList();
        ArrayList<Shapes> copiedShapesList = new ArrayList<>();

        for(Shapes shape : shapesList){
            if(shape.isSelected()){
                copiedShapesList.add(copyShape(shape));
            }
        }

        appState.setCopiedShapeList(copiedShapesList);
    }
}
