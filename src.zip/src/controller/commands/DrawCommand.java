package controller.commands;

import controller.MyMouseHandler;
import controller.shapes.*;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import static controller.shapes.ShapeMods.redraw;

public class DrawCommand implements IUndoRedo {

     private IApplicationState appState;
     private PaintCanvasBase paintCanvas;
     private Shapes added;

    @Override
    public void run() {
        CommandHistory.add(this);
        this.appState = MyMouseHandler.getAppState();
        this.paintCanvas = MyMouseHandler.getPaintCanvas();
        drawShape();
    }
    @Override
    public void redo() {
        appState.addShapeToShapeList(added);
        redraw(appState.getShapeList(), paintCanvas);
    }
    @Override
    public void undo() {
        appState.removeShape(added);
        redraw(appState.getShapeList(), paintCanvas);
    }

    private void drawShape(){
        ShapesFactory factory = new ShapesFactory();
        Shapes shape = factory.makeShape();
        added = shape;
        appState.addShapeToShapeList(shape);
        switch (shape.getShapeType()){
            case RECTANGLE:
                rectangle rectangle = new rectangle();
                rectangle.drawShape(shape, paintCanvas);
                break;
            case ELLIPSE:
                ellipse ellipse = new ellipse();
                ellipse.drawShape(shape, paintCanvas);
                break;
            case TRIANGLE:
                triangle triangle = new triangle();
                triangle.drawShape(shape, paintCanvas);
        }

    }
}
