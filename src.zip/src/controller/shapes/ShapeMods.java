package controller.shapes;

import model.ShapeType;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;
import java.util.ArrayList;

import static model.ShapeType.*;


public class ShapeMods implements IShapeMods {

    public static Shapes copyShape(Shapes toCopy){
        ShapesFactory factory = new ShapesFactory();
        Shapes tmp = factory.makeShape();
        int dx = 50, dy = 10;

        if (toCopy.getShapeType().equals(TRIANGLE)) {
            int[] xArr = toCopy.getxArr();
            int[] yArr = toCopy.getyArr();
            int[] xArr1 = new int[3], yArr1 = new int[3];

            for(int i = 0; i < 3; i++){xArr1[i] = xArr[i] + dx; yArr1[i] = yArr[i] + dy;}

            tmp.setxArr(xArr1);
            tmp.setyArr(yArr1);
        } else {
            tmp.setX(dx + toCopy.getX());
            tmp.setY(dy + toCopy.getY());
        }
        tmp.setSecondary(toCopy.getSecondary());
        tmp.setPrimary(toCopy.getPrimary());
        tmp.setShadeType(toCopy.getShadeType());
        tmp.setShapeType(toCopy.getShapeType());
        tmp.setWidth(toCopy.getWidth());
        tmp.setHeight(toCopy.getHeight());
        tmp.setSelected(false);
        tmp.setGroupNumber(toCopy.getGroupNumber());
        return tmp;
    }
    public static void redraw(ArrayList<Shapes> shapeList, PaintCanvasBase paintCanvas){
        Graphics2D graphics2d = paintCanvas.getGraphics2D();
        graphics2d.setColor(Color.white);
        graphics2d.fillRect(0 ,0, paintCanvas.getWidth(), paintCanvas.getHeight());
        for (Shapes shape : shapeList) {
            switch (shape.getShapeType()) {
                case RECTANGLE:
                    rectangle rectangle = new rectangle();
                    rectangle.drawShape(shape, paintCanvas);
                    if(shape.isSelected())
                        rectangle.selectShape(shape, paintCanvas);
                    break;
                case ELLIPSE:
                    ellipse ellipse = new ellipse();
                    ellipse.drawShape(shape, paintCanvas);
                    if(shape.isSelected())
                        ellipse.selectShape(shape, paintCanvas);
                    break;
                case TRIANGLE:
                    triangle triangle = new triangle();
                    triangle.drawShape(shape, paintCanvas);
                    if(shape.isSelected())
                        triangle.selectShape(shape, paintCanvas);
                    break;
            }
        }
    }

    public static void selectGroup(int groupNumber, IApplicationState appState, PaintCanvasBase paintCanvas){
        ArrayList<Shapes> shapesList =appState.getShapeList();
            for(Shapes shape : shapesList){
                if(shape.getGroupNumber() == groupNumber){
                    shape.setSelected(true);
                    switch (shape.getShapeType()) {
                        case RECTANGLE:
                            rectangle rectangle = new rectangle();
                            rectangle.selectShape(shape, paintCanvas);
                            break;
                        case ELLIPSE:
                            ellipse ellipse = new ellipse();
                            ellipse.selectShape(shape, paintCanvas);
                            break;
                        case TRIANGLE:
                            triangle triangle = new triangle();
                            triangle.selectShape(shape, paintCanvas);
                            break;
                    }
                }
        }
    }
}
