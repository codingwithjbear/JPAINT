package controller.shapes;

import view.gui.PaintCanvas;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

/*
Strategy pattern (IDrawSelectShape, ellipse, rectangle, triangle) implemented and used in SelectCommand, MoveCommand, DrawCommand
 */
public interface IDrawSelectShape {
     void drawShape(Shapes shape, PaintCanvasBase paintCanvas);
     void selectShape(Shapes shape, PaintCanvasBase paintCanvas);
}
