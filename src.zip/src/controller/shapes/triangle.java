package controller.shapes;

import view.gui.PaintCanvas;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

public class triangle implements IDrawSelectShape {

    @Override
    public void drawShape(Shapes shape, PaintCanvasBase paintCanvas) {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();

        int[] xArr = shape.getxArr(), yArr = shape.getyArr();

        switch (shape.getShadeType()){
            case OUTLINE_AND_FILLED_IN:
                graphics2d.setColor(shape.getPrimary());
                graphics2d.fillPolygon(xArr,yArr,3);
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.setColor(shape.getSecondary());
                graphics2d.drawPolygon(xArr,yArr,3);
                break;
            case FILLED_IN:
                graphics2d.setColor(shape.getPrimary());
                graphics2d.fillPolygon(xArr,yArr,3);
                break;
            case OUTLINE:
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.setColor(shape.getPrimary());
                graphics2d.drawPolygon(xArr,yArr,3);
        }

    }

    @Override
    public void selectShape(Shapes shape, PaintCanvasBase paintCanvas) {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();
        Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
        graphics2d.setStroke(stroke);
        graphics2d.setColor(Color.BLACK);
        int[] xArr = shape.getxArr(), yArr = shape.getyArr();
        graphics2d.drawPolygon(xArr,yArr,3);
    }

}
