package controller.shapes;

import controller.MyMouseHandler;
import model.ShapeShadingType;
import model.ShapeType;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import static model.shapeColorToColor.getColor;

import java.awt.*;
import java.util.ArrayList;

public class ShapesFactory {

        public Shapes makeShape(){
                IApplicationState appState = MyMouseHandler.getAppState();
                Point startPoint = MyMouseHandler.getStartPoint() != null ? MyMouseHandler.getStartPoint() : new Point(0,0), endPoint = MyMouseHandler.getEndPoint() != null ? MyMouseHandler.getEndPoint() : new Point(0,0);
                int x = Math.min(startPoint.x, endPoint.x), y = Math.min(startPoint.y, endPoint.y);
                int width = Math.abs(startPoint.x - endPoint.x), height = Math.abs(startPoint.y - endPoint.y);
                int[] xArr = new int[]{startPoint.x,endPoint.x, startPoint.x}, yArr = new int[]{startPoint.y, endPoint.y, endPoint.y};

                shapeBuilder shapeBuilder = new shapeBuilder();


                shapeBuilder.setDimensions(x,y,width,height)
                        .setPrimaryColor(getColor(appState.getActivePrimaryColor().toString()))
                        .setSecondaryColor(getColor(appState.getActiveSecondaryColor().toString()))
                        .setShadeType(appState.getActiveShapeShadingType())
                        .setShapeType(appState.getActiveShapeType())
                        .setPoints(startPoint,endPoint)
                        .setArrays(xArr,yArr);


                return shapeBuilder.buildShape();
        }




}
