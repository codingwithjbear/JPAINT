package controller.shapes;

import view.interfaces.PaintCanvasBase;

import java.awt.*;

public class ellipse implements IDrawSelectShape {
    @Override
    public void drawShape(Shapes shape, PaintCanvasBase paintCanvas) {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();

        int x = shape.getX(), y = shape.getY(), width = shape.getWidth(), height = shape.getHeight();

        switch (shape.getShadeType()){
            case OUTLINE_AND_FILLED_IN:
                graphics2d.setColor(shape.getPrimary());
                graphics2d.fillOval(x, y, width, height);
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.setColor(shape.getSecondary());
                graphics2d.drawOval(x, y, width, height);
                break;
            case FILLED_IN:
                graphics2d.setColor(shape.getPrimary());
                graphics2d.fillOval(x, y, width, height);
                break;
            case OUTLINE:
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.setColor(shape.getPrimary());
                graphics2d.drawOval(x, y, width, height);
        }


    }

    @Override
    public void selectShape(Shapes shape, PaintCanvasBase paintCanvas) {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();
        Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
        graphics2d.setStroke(stroke);
        graphics2d.setColor(Color.BLACK);
        graphics2d.drawOval(shape.getX() - 5, shape.getY() - 5, shape.getWidth() + 10, shape.getHeight() + 10);
    }
}
