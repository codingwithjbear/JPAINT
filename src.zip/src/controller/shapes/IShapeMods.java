package controller.shapes;

import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.util.ArrayList;

/*
static factory (IShapeMods, ShapeMods) implemented and used in CopyCommand, PasteCommand, MoveCommand, SelectCommand, DeleteCommand
 */
public interface IShapeMods {

    static Shapes copyShape(Shapes toCopy) {
        return null;
    }

    static void redraw(ArrayList<Shapes> shapeList, PaintCanvasBase paintCanvas){}


    static void selectGroup(int groupNumber, IApplicationState appState){}

}
