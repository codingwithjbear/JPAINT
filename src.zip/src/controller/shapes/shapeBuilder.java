package controller.shapes;

import model.ShapeShadingType;
import model.ShapeType;

import java.awt.*;

public class shapeBuilder {

    private int x,y,width,height;
    private ShapeShadingType shadeType;
    private ShapeType shapeType;
    private Color primary, secondary;
    private Point startPoint, endPoint;
    private int[] xArr,yArr;

    public shapeBuilder setDimensions(int x, int y, int width, int height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        return this;
    }

    public shapeBuilder setShadeType(ShapeShadingType shadeType){
        this.shadeType = shadeType;
        return this;
    }

    public shapeBuilder setShapeType(ShapeType shapeType){
        this.shapeType = shapeType;

        return this;
    }

    public shapeBuilder setPrimaryColor(Color primary){
        this.primary = primary;
        return this;
    }

    public shapeBuilder setSecondaryColor(Color secondary){
        this.secondary = secondary;
        return this;
    }

    public shapeBuilder setPoints(Point startPoint, Point endPoint){
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        return this;
    }

    public shapeBuilder setArrays(int[] xArr, int[] yArr){
        this.xArr = xArr;
        this.yArr = yArr;
        return this;
    }

    public Shapes buildShape(){
        return new Shapes(x,y,width,height,shapeType,shadeType, primary, secondary, startPoint, endPoint, xArr, yArr);
    }


}
