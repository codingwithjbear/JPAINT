package controller.shapes;

import controller.MyMouseHandler;
import model.ShapeShadingType;
import model.ShapeType;


import java.awt.*;

import static model.shapeColorToColor.getColor;

public class Shapes {
    private int x,y,width,height;
    private ShapeShadingType shadeType;
    private ShapeType shapeType;
    private Color primary, secondary;
    private Point startPoint, endPoint;
    private int[] xArr, yArr;
    private int dx, dy;
    private boolean isSelected, isCopy = false;
    private int groupNumber = -1;

    /*
    builder pattern (Shapes, shapeBuilder, ShapesFactory) implemented and used in SelectCommand, DrawCommand, MoveCommand
     */

    private Shapes(){

    }

    public Shapes(int x, int y, int width, int height, ShapeType shapeType, ShapeShadingType shadeType,
                     Color primary, Color secondary, Point startPoint, Point endPoint, int[] xArr, int[] yArr){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.shapeType = shapeType;
        this.shadeType = shadeType;
        this.primary = primary;
        this.secondary = secondary;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.xArr = xArr;
        this.yArr = yArr;

    }

    public int[] getxArr() {
        return xArr;
    }

    public int[] getyArr() {
        return yArr;
    }

    public void setxArr(int[] xArr) {
        this.xArr = xArr;
    }

    public void setyArr(int[] yArr) {
        this.yArr = yArr;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public ShapeShadingType getShadeType() {
        return shadeType;
    }

    public ShapeType getShapeType() {
        return shapeType;
    }

    public Color getPrimary() {
        return primary;
    }

    public Color getSecondary() {
        return secondary;
    }

    public Point getStartPoint() {
        return startPoint;
    }

    public Point getEndPoint() {
        return endPoint;
    }

    public int getDx(){return  dx;}

    public int getDy(){return dy;}

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setDx(int dx){this.dx = dx;}

    public  void setDy(int dy){this.dy = dy;}

    public void setStartPoint(Point startPoint) {
        this.startPoint = startPoint;
    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }

    public void setShadeType(ShapeShadingType shadeType) {
        this.shadeType = shadeType;
    }

    public void setShapeType(ShapeType shapeType) {
        this.shapeType = shapeType;
    }

    public void setPrimary(Color primary) {
        this.primary = primary;
    }

    public void setSecondary(Color secondary) {
        this.secondary = secondary;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setCopy(boolean selected) {
        isCopy = selected;
    }

    public boolean isCopy() {
        return isCopy;
    }

    public int getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(int groupNumber) {
        this.groupNumber = groupNumber;
    }
}
