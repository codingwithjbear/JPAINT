package controller;

//MVC (IJPaintController, JPaintController) used in Main.java
public interface IJPaintController {
    void setup();
}
