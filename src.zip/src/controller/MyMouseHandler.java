package controller;

import controller.commands.DrawCommand;
import controller.commands.ICommand;
import controller.commands.MoveCommand;
import controller.commands.SelectCommand;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class MyMouseHandler extends JPanel implements MouseListener {

        private static Point startPoint;
        private static Point endPoint;
        private static PaintCanvasBase paintCanvas;
        private static IApplicationState appState;

    public MyMouseHandler(PaintCanvasBase paintCanvas, IApplicationState appState) {
        MyMouseHandler.paintCanvas = paintCanvas;
        MyMouseHandler.appState = appState;
    }

    public void mousePressed(MouseEvent e) {
            startPoint = new Point(e.getX(), e.getY());
            endPoint = startPoint;
            repaint();

    }
        public void mouseReleased(MouseEvent e) {
            endPoint = new Point(e.getX(), e.getY());
            ICommand command;
            switch (appState.getActiveStartAndEndPointMode()){
                case DRAW:
                    command = new DrawCommand();
                    command.run();
                    break;
                case MOVE:
                    command = new MoveCommand();
                    command.run();
                    break;
                case SELECT:
                    command = new SelectCommand();
                    command.run();
                    break;
            }
            repaint();
            startPoint = endPoint = null;

        }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }
    public static PaintCanvasBase getPaintCanvas() {
        return paintCanvas;
    }

    public static Point getStartPoint() {
        return startPoint;
    }

    public static Point getEndPoint(){
        return endPoint;
    }

    public static IApplicationState getAppState() {
        return appState;
    }

}
